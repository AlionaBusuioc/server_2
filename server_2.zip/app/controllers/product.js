var numeral = require('numeral');
var bcrypt = require('bcrypt-nodejs');
var dateFormat = require('dateformat');

// exports.loggedIn = function(req, res, next)
// {
// 	if (req.session.user) { // req.session.passport._id

// 		next();

// 	} else {

// 		res.redirect('/login');

// 	}

// }

// exports.signup = function(req, res) {

// 	if (req.session.user) {

// 		res.redirect('/home');

// 	} else {

// 		res.render('signup', {
// 			error : req.flash("error"),
// 			success: req.flash("success"),
// 			session:req.session,
// 			title: "Test ok"
// 		});
// 	}

const fs = require('fs')
exports.productIndex = (req, res) => {
    fs.readFile('./database/products.json', (err, data) => {
        if(!err){
            res.append('Content-type', 'application/json')
            res.send(data.toString())
        } else {
            console.log(err);
        }
    });
}
// }