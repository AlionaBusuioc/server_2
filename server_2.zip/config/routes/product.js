const product = require('../../app/controllers/product');
const home = require('../../app/controllers/home');
const product = require('../../app/controllers/product');
// var home = require('../app/controllers/home');

//you can include all your controllers

module.exports = function (app) {

    app.get('/', home.home);//home

app.get('/products', product.productIndex)
app.get('/products/:productid', product.productDetails)
app.delete('/products/:productid', product.productDelete)
}
